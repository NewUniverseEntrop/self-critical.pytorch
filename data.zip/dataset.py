
import json

import os
with open('train_list.txt') as f:
    train_list = f.readlines()
with open('val_list.txt') as f:
    val_list = f.readlines()
train_list = [x.strip().split("/")[1] for x in train_list] 

val_list=[x.split("/")[1].strip() for x in val_list] 


directory ="./output/"

new = {"images": [], "dataset": "youcook2"}
count = 0
for filename in os.listdir(directory):
    if filename.endswith(".txt") or filename.endswith(".png"):
        f = open(directory+"/"+filename, "r")
        data=f.read()
        #print(data)
        n=filename[:filename.index(".")]
    
        split="train"
        
        if n.split("_")[0] in train_list:
            split="train"
        elif n.split("_")[0] in val_list:
            split="val"
        else:
            split="test"
        

        if data!="":
            new["images"].append({"sentids": [0], "image_id":count,"cocoid":count, "split":split, "filepath":"../raw_images","filename": n+".jpg", "imgid": count, "sentences": [
                {"tokens": data.split(), "raw": data, "imgid": count, "sentid": 0}]})
        count = count+1

    else:
        continue



'''
count = 0
for x in data:
    if data[x] != "":
        new["images"].append({"sentids": [0], "split": "train", "filename": x, "imgid": count, "sentences": [
                             {"tokens": data[x].split(), "raw": data[x], "imgid": count, "sentid": 0}]})
        count = count+1
'''

with open('../self-critical.pytorch-master/data/data.json', 'w') as fp:
    json.dump(new, fp)
