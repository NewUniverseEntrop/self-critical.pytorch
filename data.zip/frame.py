
import subprocess
import os
directory = '../raw_videos/'

for subdirectory in os.listdir(directory):
           if subdirectory.find(".") == -1:
                mp4_file =directory+subdirectory
                command ="ffmpeg  -ss 00:00:00 -i "+mp4_file+" -r 1/10 "+"../raw_images/"+subdirectory+"_%4d.jpg"
                os.system(command)
