
import subprocess
import os
directory = './audio_chunks/'

for videoName in os.listdir(directory):
    for chunkName in os.listdir(directory+videoName):
        print(videoName+chunkName)
        if chunkName.endswith(".wav") == True:
                mp4_file =directory+videoName+"/"+chunkName
                command =os.path.dirname(os.path.realpath(__file__))+"/"+"ffmpeg/ffmpeg/bin/ffmpeg.exe  -ss 00:00:00 -i "+mp4_file+" -vframes 1 -q:v 2 "+"../raw_images/"+chunkName+"_%4d.jpg"
                os.system(command)