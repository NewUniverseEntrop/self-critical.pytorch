
import subprocess


import os
directory = '../raw_videos/'


for subdirectory in os.listdir(directory):
        if subdirectory.endswith(".wav") == False:

            mp4_file =directory+subdirectory
            print(mp4_file)
            command ="ffmpeg -i "+mp4_file+" "+mp4_file+".wav"
            os.system(command)
